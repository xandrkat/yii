<?php
return [
    'homeUrl' => '/',
    'components' => [
        'request' => [
            'enableCsrfValidation' => false,
        ],
    ],
];
