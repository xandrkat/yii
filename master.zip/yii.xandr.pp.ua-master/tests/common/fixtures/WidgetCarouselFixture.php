<?php

namespace tests\common\fixtures;

use yii\test\ActiveFixture;


class WidgetCarouselFixture extends ActiveFixture
{
    public $tableName = 'widget_carousel';
}
