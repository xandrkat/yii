<?php
/**
 * Created by PhpStorm.
 * User: rsuarez
 * Date: 8/25/15
 * Time: 10:43 PM
 */

return [
    [
        'item_name' => "administrator",
        'user_id' => "1",
        'created_at' => '1440552894',
    ],
    [
        'item_name' => "manager",
        'user_id' => "2",
        'created_at' => '1440552894',
    ],
    [
        'item_name' => "user",
        'user_id' => "3",
        'created_at' => '1440552894',
    ],
];
