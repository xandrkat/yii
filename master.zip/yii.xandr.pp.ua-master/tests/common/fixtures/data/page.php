<?php

/**
 * Created by PhpStorm.
 * User: Alfred
 * Date: 20.10.2017
 * Time: 20:03
 */

return [
    [
        "id" => "1",
        "slug" => "about",
        "title" => "About",
        "body" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "view" => "",
        "status" => "1",
        "created_at" => "1508525930",
        "updated_at" => "1508525930"
    ]
];