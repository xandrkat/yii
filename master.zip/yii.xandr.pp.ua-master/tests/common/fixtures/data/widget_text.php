<?php
/**
 * Created by PhpStorm.
 * User: Alfred
 * Date: 22.10.2017
 * Time: 15:50
 */

return [
    [
        "id" => "1",
        "key" => "backend_welcome",
        "title" => "Welcome to backend",
        "body" => "<p>Welcome to Yii2 Starter Kit Dashboard</p>",
        "status" => "1",
        "created_at" => "1508593313",
        "updated_at" => "1508593313"
    ],
    [
        "id" => "2",
        "key" => "ads-example",
        "title" => "Google Ads Example Block",
        "body" => "<div class=\"lead\">\r\n                <script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>\r\n                <ins class=\"adsbygoogle\"\r\n                     style=\"display:block\"\r\n                     data-ad-client=\"ca-pub-9505937224921657\"\r\n                     data-ad-slot=\"2264361777\"\r\n                     data-ad-format=\"auto\"></ins>\r\n                <script>\r\n                (adsbygoogle = window.adsbygoogle || []).push({});\r\n                </script>\r\n            </div>",
        "status" => "0",
        "created_at" => "1508593313",
        "updated_at" => "1508593313"
    ]
];