<?php

return [
    [
        "id" => "1",
        "carousel_id" => "1",
        "base_url" => "./",
        "path" => "img/yii2-starter-kit.gif",
        "type" => "image/gif",
        "url" => "/",
        "caption" => "",
        "status" => "1",
        "order" => "0",
        "created_at" => "",
        "updated_at" => ""
    ]
];
