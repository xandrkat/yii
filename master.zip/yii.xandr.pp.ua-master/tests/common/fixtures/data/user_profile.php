<?php
/**
 * @author Eugene Terentev <eugene@terentev.net>
 */
return [
    [
        'user_id' => 1,
        'locale' => 'en_US'
    ],
    [
        'user_id' => 2,
        'locale' => 'en_US'
    ],
    [
        'user_id' => 3,
        'locale' => 'en_US'
    ],
];