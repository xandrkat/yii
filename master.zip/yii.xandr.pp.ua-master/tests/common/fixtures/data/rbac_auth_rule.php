<?php
/**
 * Created by PhpStorm.
 * User: Alfred
 * Date: 20.10.2017
 * Time: 17:04
 */

return [
    [
        "name" => "ownModelRule",
        "data" => "TzoyOToiY29tbW9uXHJiYWNccnVsZVxPd25Nb2RlbFJ1bGUiOjM6e3M6NDoibmFtZSI7czoxMjoib3duTW9kZWxSdWxlIjtzOjk6ImNyZWF0ZWRBdCI7aToxNTA4NTA3Nzg4O3M6OToidXBkYXRlZEF0IjtpOjE1MDg1MDc3ODg7fQ==",
        "created_at" => "1508507788",
        "updated_at" => "1508507788"
    ]
];