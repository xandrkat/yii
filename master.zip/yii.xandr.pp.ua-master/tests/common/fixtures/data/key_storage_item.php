<?php
/**
 * @author Eugene Terentev <eugene@terentev.net>
 */
return [
    [
        'key' => 'frontend.maintenance',
        'value' => 'disabled'
    ]
];