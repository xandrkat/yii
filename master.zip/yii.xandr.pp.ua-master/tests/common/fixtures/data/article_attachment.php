<?php
/**
 * @author Eugene Terentev <eugene@terentev.net>
 */
return [
    [
        'id' => 1,
        'article_id' => 1,
        'path' => 'test-file.png',
        'name' => 'Test File',
        'base_url' => 'http://example.org',
        'size' => 1024
    ]
];