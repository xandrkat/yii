<?php
/**
 * @author Eugene Terentev <eugene@terentev.net>
 */
return [
    [
        'id' => 1,
        'title' => 'Test Category',
        'slug' => 'test-category',
        'status' => 1
    ]
];