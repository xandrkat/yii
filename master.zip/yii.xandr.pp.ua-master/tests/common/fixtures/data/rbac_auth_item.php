<?php

/**
 * Created by PhpStorm.
 * User: Alfred
 * Date: 20.10.2017
 * Time: 16:03
 */

return [
    [
        "name" => "administrator",
        "type" => "1",
        "description" => "",
        "rule_name" => null,
        "data" => "",
        "created_at" => "1508507788",
        "updated_at" => "1508507788"
    ],
    [
        "name" => "editOwnModel",
        "type" => "2",
        "description" => "",
        "rule_name" => "ownModelRule",
        "data" => "",
        "created_at" => "1508507788",
        "updated_at" => "1508507788"
    ],
    [
        "name" => "loginToBackend",
        "type" => "2",
        "description" => "",
        "rule_name" => null,
        "data" => "",
        "created_at" => "1508507788",
        "updated_at" => "1508507788"
    ],
    [
        "name" => "manager",
        "type" => "1",
        "description" => "",
        "rule_name" => null,
        "data" => "",
        "created_at" => "1508507787",
        "updated_at" => "1508507787"
    ],
    [
        "name" => "user",
        "type" => "1",
        "description" => "",
        "rule_name" => null,
        "data" => "",
        "created_at" => "1508507787",
        "updated_at" => "1508507787"
    ]
];