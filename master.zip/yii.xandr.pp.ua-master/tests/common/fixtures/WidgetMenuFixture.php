<?php

namespace tests\common\fixtures;

use yii\test\ActiveFixture;


class WidgetMenuFixture extends ActiveFixture
{
    public $tableName = 'widget_menu';
}
